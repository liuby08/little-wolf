create
    definer = root@localhost procedure showinport(IN id int)
begin
 select * from bus_inport where bus_inport.goodsid=id;
end;

