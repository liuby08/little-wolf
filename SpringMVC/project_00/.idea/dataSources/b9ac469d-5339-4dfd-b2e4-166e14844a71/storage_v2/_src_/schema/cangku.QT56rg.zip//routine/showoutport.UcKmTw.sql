create
    definer = root@localhost procedure showoutport(IN id int)
begin
 SELECT * FROM bus_outport WHERE bus_outport.goodsid=id;
end;

