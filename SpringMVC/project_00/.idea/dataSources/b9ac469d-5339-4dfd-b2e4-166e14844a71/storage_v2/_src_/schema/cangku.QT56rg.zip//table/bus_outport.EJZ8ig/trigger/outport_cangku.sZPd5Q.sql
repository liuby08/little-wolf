create definer = root@localhost trigger outport_cangku
    before insert
    on bus_outport
    for each row
BEGIN
DECLARE num2 INT DEFAULT 0;
DECLARE num1 INT DEFAULT 0;
DECLARE num INT DEFAULT 0;
SELECT lownum INTO num FROM bus_goods WHERE id=new.goodsid;
SELECT number INTO num2 FROM bus_goods WHERE id=new.goodsid;
UPDATE bus_goods SET number=number-new.number WHERE id= new.goodsid;
SELECT number INTO num1 FROM bus_goods WHERE id=new.goodsid;
IF  num1<num THEN
SET new.number=num2-num;
UPDATE bus_goods SET number=num WHERE id= new.goodsid;
END IF;
END;

