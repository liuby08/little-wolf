create
    definer = root@localhost procedure showinyear(IN ye int)
BEGIN
SELECT *
FROM `bus_inport` 
WHERE YEAR(`bus_inport`.`inporttime`)= ye
GROUP BY DATE_FORMAT(`inporttime`,'%Y'),id
ORDER BY DATE_FORMAT(`inporttime`,'%Y-%m-%d') ASC ;
END;

