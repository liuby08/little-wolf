create
    definer = root@localhost procedure shownumber(IN id int)
begin
 SELECT number as '库存' ,`goodsname` as '货物' FROM bus_goods WHERE bus_goods.id=id;
end;

