create
    definer = root@localhost procedure showinmon(IN mon int)
BEGIN
SELECT *
FROM `bus_inport`
WHERE MONTH(`bus_inport`.`inporttime`)= mon
GROUP BY DATE_FORMAT(`inporttime`,'%Y-%m'),id
ORDER BY DATE_FORMAT(`inporttime`,'%Y-%m-%d') ASC ;
END;

