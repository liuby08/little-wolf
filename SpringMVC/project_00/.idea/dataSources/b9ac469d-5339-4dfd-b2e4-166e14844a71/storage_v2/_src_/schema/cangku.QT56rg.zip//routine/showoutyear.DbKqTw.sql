create
    definer = root@localhost procedure showoutyear(IN ye int)
BEGIN
SELECT *
FROM bus_outport 
WHERE year(bus_outport.outputtime)= ye
GROUP BY DATE_FORMAT(`outputtime`,'%Y'),id
ORDER BY DATE_FORMAT(`outputtime`,'%Y-%m-%d') ASC ;
END;

