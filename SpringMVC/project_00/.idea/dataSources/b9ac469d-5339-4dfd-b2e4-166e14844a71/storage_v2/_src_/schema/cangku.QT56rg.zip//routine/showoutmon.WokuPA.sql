create
    definer = root@localhost procedure showoutmon(IN mon int)
begin
SELECT *
FROM bus_outport 
WHERE MONTH(bus_outport.outputtime)= mon
GROUP BY DATE_FORMAT(`outputtime`,'%Y-%m'),id
ORDER BY DATE_FORMAT(`outputtime`,'%Y-%m-%d') ASC ;
end;

