create definer = root@localhost trigger delete_js
    after delete
    on 驾驶员
    for each row
BEGIN
delete from `车辆使用` where `驾驶证号`=old.`驾驶证号`;
DELETE FROM `事故` WHERE `驾驶证号`=old.`驾驶证号`;
END;

